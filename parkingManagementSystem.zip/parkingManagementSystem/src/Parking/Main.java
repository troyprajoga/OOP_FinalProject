package Parking;

public class Main{
    public static void main(String[] args)
    {
        //call TicketGUI class
        TicketGUI ticket = new TicketGUI();
    }

}
